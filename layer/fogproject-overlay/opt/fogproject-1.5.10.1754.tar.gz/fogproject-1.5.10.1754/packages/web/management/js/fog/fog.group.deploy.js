(function($) {
    DeployStuff();
})(jQuery);
